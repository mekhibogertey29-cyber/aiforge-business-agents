# AIForge Business Agents

Isolated multi-agent system that creates digital products, lists them, markets them, tracks sales, and optimizes — all while following strict isolation rules (one agent = one job = one output file).

Inspired by the Anthropic multi-agent findings: older models flooded projects with hundreds of unusable overlapping pieces of work. Newer, better results came from agents that stayed in their own corners and never touched each other’s output. This project enforces that pattern.

## Features

- 8 specialized agents, each with a single owned job
- Zero shared mutable state between agents
- Live Streamlit dashboard — click any agent to inspect its task, status, and full private output
- Simulated sales & revenue tracking (ready for real platform hooks)
- Digital product focus (planners, AI art packs, ebooks, Notion templates, etc.) for fast iteration
- One-command full pipeline run

## Quick Start

```bash
# 1. Clone
git clone https://github.com/YOUR_USERNAME/aiforge-business-agents.git
cd aiforge-business-agents

# 2. Install
pip install -r requirements.txt

# 3. Run the full agent chain
PYTHONPATH=. python orchestrator.py

# 4. Open the dashboard
streamlit run dashboard/app.py
```

## Project Structure

```
aiforge-business-agents/
├── agents/                  # Each agent owns exactly one job
│   ├── 01_ideator.py
│   ├── 02_researcher.py
│   ├── 03_designer.py
│   ├── 04_copywriter.py
│   ├── 05_lister.py
│   ├── 06_marketer.py
│   ├── 07_sales_tracker.py
│   ├── 08_optimizer.py
│   └── base_agent.py
├── dashboard/
│   └── app.py               # Clickable command center
├── outputs/                 # Private output files (one per agent)
├── data/                    # Status + sales log
├── config.py
├── orchestrator.py
└── requirements.txt
```

## Isolation Rules (enforced)

- Every agent receives only the inputs it needs
- Every agent writes only to its own file
- No agent ever reads or writes another agent’s output
- Orchestrator is the single coordinator
- Fresh context per run

## Dashboard

The Streamlit dashboard lets you:

- See live KPIs (revenue, units, price)
- Click any of the 8 agents
- View their exact owned job, current task, last update, and full private output
- Inspect sales history and charts
- Trigger a full pipeline run with one button

## Next Steps

- Add real LLM calls (OpenAI / Anthropic / xAI) inside the agents
- Connect real platforms (Gumroad, Etsy, Stripe test mode, Printful)
- Schedule the orchestrator (cron / GitHub Actions)
- Add more specialized agents without breaking isolation

## License

MIT
